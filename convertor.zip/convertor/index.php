<?php

require("CsvModel.php");
require("DbModel.php");

$patchmdb = $_SERVER["DOCUMENT_ROOT"]."/convertor/123.MDB";
$patchcsv = "123.csv";
$tablename = "table";


dbModel::connectMdb($patchmdb);
$convert = new csvModel($patchcsv);
$arrays = $convert->insertKeyToArray();
$result = DbModel::insertArrays($tablename, $arrays);
echo "Vložené riadky: $result";


?>